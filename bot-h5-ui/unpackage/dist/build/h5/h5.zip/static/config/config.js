import {getIp} from '@/utils/util.js'

export const webSocketUrl=getIp()
export const botId="-1002145384896"
export const systemid='69q6fq69q6dq68q61q69q6aq6cq61q68q68q68'
export default {
    webSocketUrl,
	botId,
	systemid
}